const express = require('express');
const server = express();
const filme2010 = require('./src/data/filme2010.json');
const filme2022 = require('./src/data/filme2022.json');
const jsonVazio = require('./src/data/jsonVazio.json');

server.get('/filme/:lancamento', (req, res) =>{
    if (req.params.lancamento == 2010) {
        return res.json(filme2010)
    }

    if (req.params.lancamentos == 2022) {
        return res.json(filme2022)
    }

    return res.json(jsonVazio);
});
server.get('/filme', (req, res) =>{
    return res.json(jsonVazio);
});
server.get('', (req, res) => {
    return res.json(jsonVazio);
});


server.listen(3000, () =>{
    console.log('Servidor funcionando...');
})